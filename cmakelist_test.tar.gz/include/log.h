#ifndef _LOG_H_
#define _LOG_H_

#include <string>
#include <map>
#include <log4cplus/logger.h>
using namespace log4cplus;

#define MAX_FILE_SIZE    (500 * 1024 * 1024)
#define MAX_FILE_COUNT   (50)
#define OPT_FILE_PATH    "/opt/logs/"
#define DATA_FILE_PATH   "/data/applogs/"
#define TMP_FILE_PATH    "/tmp/"
#define PATTERN_PREFIX   "%D{%Y-%m-%d %H:%M:%S.%q} %H "
#define PATTERN_MID      " [%p] %T "
#define PATTERN_SUFFIX   " %m%n"
#define XMDT_PREFIX      "#XMDT#{traceID="
#define XMDT_SUFFIX      "}#XMDT#" 
#define DEFAULT_LOG_NAME "program"
#define DEBUG_LOG_SUFFIX  ".log.debug"
#define INFO_LOG_SUFFIX  ".log.info"
#define WARN_LOG_SUFFIX  ".log.warn"
#define ERROR_LOG_SUFFIX ".log.error"
#define DETAULT_APP_KEY  "%t"
#define MAX_STR_LENGTH   (100)
#define MAX_BUFFER_LENGTH   (1024)

#define LEVEL_CONF_PATH "/opt/logs/log.conf"
#define LEVEL_DEBUG_STR "debug"
#define LEVEL_DEBUG (1)
#define LEVEL_INFO_STR "info"
#define LEVEL_INFO  (2)
#define LEVEL_WARN_STR "warn"
#define LEVEL_WARN  (3)
#define LEVEL_ERROR_STR "error"
#define LEVEL_ERROR (4)
#define LEVEL_OFF_STR "off"
#define LEVEL_OFF (5)


class CLog
{
    public:
   	static CLog& getLogger();
	static void init(std::string& _log_name, std::string& _app_key);
	static void setLevel(std::string &glevel);
	static void shutDown(void);
	void debug(const std::string &log_info);
	void debug(const char* log_info, ...);
	void info(const std::string &log_info);
	void info(const char* log_info, ...);
	void warn(const std::string &log_info);
	void warn(const char* log_info, ...);
	void error(const std::string &log_info);
	void error(const char* log_info, ...);
	void putTag(std::map<std::string, std::string>& log_map);
	void putTag(std::map<char*, char*>& log_map);

    private:
	static std::string app_key;
	static std::string log_name;
	static int level;
	CLog();
	void parseConfigure(void);
	Logger& getUseLogger(void);
	unsigned long getDiskFreeSize(std::string path);
	typedef std::map<std::string, std::string>::iterator STRING_MAP_IT;
	typedef std::map<char*, char*>::iterator CHAR_MAP_IT;
};

#endif
