
#include <iostream>
#include <Test1.h>

int main(void)
{
	std::cout << "Hello word " << get(10) << std::endl;
	return 0;
}
