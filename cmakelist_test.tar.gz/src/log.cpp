#include <log.h>
#include <sstream>
#include <iostream>
#include <pthread.h>
#include <memory>
#include <stdarg.h>
#include <fstream>
#include <stdlib.h>
#include <stdio.h>
#include <cstdlib>
#include <assert.h>
#ifdef _WIN32
#include <process.h>
#else
#include <unistd.h>
#endif
#include <log4cplus/fileappender.h>
#include <log4cplus/layout.h>
#include <log4cplus/fileappender.h>
#include <log4cplus/asyncappender.h>
#include <log4cplus/loggingmacros.h>

#include <unistd.h>
#include <stdint.h>
#include <pthread.h>
#include <promtrace/TraceInterface.h>
#include <sys/time.h>
#include <sys/vfs.h>


using namespace log4cplus;
using namespace log4cplus::helpers;

//static Logger global_pLogger;
static Logger debug_pLogger;
static Logger info_pLogger;
static Logger error_pLogger;
static Logger warn_pLogger;


std::string CLog::app_key = DETAULT_APP_KEY;
std::string CLog::log_name = DEFAULT_LOG_NAME;
int CLog::level = LEVEL_DEBUG;

CLog::CLog()
{

    std::string log_path;
    //std::fstream _file;
    unsigned long opt_size = getDiskFreeSize(OPT_FILE_PATH);
    unsigned long data_size = getDiskFreeSize(DATA_FILE_PATH);
    if ((opt_size == 0) && (data_size == 0)) {
        log_path = TMP_FILE_PATH;
    } else if (data_size >= opt_size) {
        log_path = DATA_FILE_PATH;
    } else {
        log_path = OPT_FILE_PATH;
    }
    #if 0
    _file.open(OPT_FILE_PATH,std::ios::in);
    if (_file)
    {
	   log_path = OPT_FILE_PATH;
    }
    else 
    {
    	_file.open(DATA_FILE_PATH,std::ios::in);
    	if (_file)
    	{
    	    log_path = DATA_FILE_PATH;
    	}
    	else
    	{
    	    log_path = TMP_FILE_PATH;
	   }
    }
    #endif

    std::string pattern = std::string(PATTERN_PREFIX) + app_key + std::string(PATTERN_MID) + log_name + std::string(PATTERN_SUFFIX);
    if (app_key == DETAULT_APP_KEY)
    {
    	char app_key_filename[MAX_STR_LENGTH]={0};
    	snprintf(app_key_filename, sizeof(app_key_filename), "%d", (int)getpid());
    	app_key = app_key_filename;
    }
    log_path += app_key;
    log_path += "/";
    log_path += log_name;
    parseConfigure();

    log4cplus::initialize(); 
    SharedAppenderPtr  debug_append(new RollingFileAppender(LOG4CPLUS_TEXT(log_path  + DEBUG_LOG_SUFFIX), MAX_FILE_SIZE, MAX_FILE_COUNT, false, true ));
    std::auto_ptr<Layout> debug_layout(new PatternLayout(pattern));
    debug_append->setLayout(debug_layout);
    AsyncAppenderPtr debug_async(new AsyncAppender (debug_append, 100));

    SharedAppenderPtr  info_append(new RollingFileAppender(LOG4CPLUS_TEXT(log_path  + INFO_LOG_SUFFIX), MAX_FILE_SIZE, MAX_FILE_COUNT, false, true ));
    std::auto_ptr<Layout> info_layout(new PatternLayout(pattern));
    info_append->setLayout(info_layout);
    AsyncAppenderPtr info_async(new AsyncAppender (info_append, 100));

    SharedAppenderPtr  warn_append(new RollingFileAppender(LOG4CPLUS_TEXT(log_path  + WARN_LOG_SUFFIX), MAX_FILE_SIZE, MAX_FILE_COUNT, false, true ));
    std::auto_ptr<Layout> warn_layout(new PatternLayout(pattern));
    warn_append->setLayout(warn_layout);
    AsyncAppenderPtr warn_async(new AsyncAppender (warn_append, 100));

    SharedAppenderPtr  error_append(new RollingFileAppender(LOG4CPLUS_TEXT(log_path  + ERROR_LOG_SUFFIX), MAX_FILE_SIZE, MAX_FILE_COUNT, false, true ));
    std::auto_ptr<Layout> error_layout(new PatternLayout(pattern));
    error_append->setLayout(error_layout);
    AsyncAppenderPtr error_async(new AsyncAppender (error_append, 100));

    //Logger::getRoot().addAppender(SharedAppenderPtr(info_append));
    Logger::Logger::getInstance(LOG4CPLUS_TEXT("DEBUG")).addAppender(SharedAppenderPtr(debug_async.get()));
    Logger::Logger::getInstance(LOG4CPLUS_TEXT("INFO")).addAppender(SharedAppenderPtr(info_async.get()));
    Logger::Logger::getInstance(LOG4CPLUS_TEXT("WARN")).addAppender(SharedAppenderPtr(warn_async.get()));
    Logger::Logger::getInstance(LOG4CPLUS_TEXT("ERROR")).addAppender(SharedAppenderPtr(error_async.get()));
    //AsyncAppenderPtr async (new AsyncAppender (info_append, 100));
    //Logger::getRoot().addAppender(SharedAppenderPtr(async.get()));

    debug_pLogger = Logger::Logger::getInstance(LOG4CPLUS_TEXT("DEBUG"));
    info_pLogger = Logger::Logger::getInstance(LOG4CPLUS_TEXT("INFO"));
    warn_pLogger = Logger::Logger::getInstance(LOG4CPLUS_TEXT("WARN"));
    error_pLogger = Logger::Logger::getInstance(LOG4CPLUS_TEXT("ERROR"));
}

CLog& CLog::getLogger()
{
    static CLog log;
    return log;
}

void CLog::setLevel(std::string &glevel)
{
    if (glevel == LEVEL_DEBUG_STR) {
        level = LEVEL_DEBUG;
    } else if (glevel == LEVEL_INFO_STR) {
        level = LEVEL_INFO;
    } else if (glevel == LEVEL_WARN_STR) {
        level = LEVEL_WARN;
    } else if (glevel == LEVEL_ERROR_STR) {
        level = LEVEL_ERROR;
    } else {
        level = LEVEL_OFF;
    }
}

void CLog::shutDown(void)
{
    Logger::shutdown();
}

void CLog::init(std::string& _log_name, std::string& _app_key)
{
    log_name = _log_name;
    app_key = _app_key;
}

unsigned long CLog::getDiskFreeSize(std::string path)
{
    unsigned long mbFreedisk = 0;
    struct statfs diskInfo;  
    if (-1 != statfs(path.c_str(), &diskInfo)) {
        unsigned long long totalBlocks = diskInfo.f_bsize;  
        unsigned long long freeDisk = diskInfo.f_bfree*totalBlocks;  
        mbFreedisk = freeDisk>>20;  
    }
    return mbFreedisk;
}

void CLog::parseConfigure(void)
{
    std::ifstream fin;
    std::string line;
    fin.open(LEVEL_CONF_PATH, std::ifstream::in);
    if (fin.is_open()) {   
        while(getline(fin, line)) {
            if (line[0] == '#' || line == "") {
                continue;
            }
            std::size_t pos = line.find("="); 
            std::string str = line.substr(pos+1);
            setLevel(str);
            break;
        }
    }
}

Logger& CLog::getUseLogger(void)
{
     switch (level){
        case LEVEL_DEBUG:
            return debug_pLogger;
        case LEVEL_INFO:
            return info_pLogger;
        case LEVEL_WARN:
            return warn_pLogger;
        case LEVEL_ERROR:
            return error_pLogger;
        default:
            return debug_pLogger;
    }
}

void CLog::debug(const std::string &log_info)
{
    //RemoteProcessCall rpc(app_key);
    if (LEVEL_DEBUG >= level) {
        LOG4CPLUS_DEBUG(getUseLogger(), log_info);
    }
}

void CLog::debug(const char* log_info, ...)
{
    if (LEVEL_DEBUG >= level){
        va_list args; 
        va_start(args, log_info);
        char buf[MAX_BUFFER_LENGTH] = {0}; 
        vsnprintf(buf, sizeof(buf), log_info, args); 
        va_end(args); 
        getUseLogger().forcedLog(log4cplus::DEBUG_LOG_LEVEL, buf); 
    }
}

void CLog::info(const std::string &log_info)
{
    //RemoteProcessCall rpc;
    //LOG4CPLUS_INFO(info_pLogger, rpc.getTraceId());
    if (LEVEL_INFO >= level) {
        LOG4CPLUS_INFO(getUseLogger(), log_info);
    }
}

void CLog::info(const char* log_info, ...)
{
    if (LEVEL_INFO >= level){
        va_list args; 
        va_start(args, log_info);
        char buf[MAX_BUFFER_LENGTH] = {0}; 
        vsnprintf(buf, sizeof(buf), log_info, args); 
        va_end(args); 
        getUseLogger().forcedLog(log4cplus::INFO_LOG_LEVEL, buf);
    } 
}

void CLog::warn(const std::string &log_info)
{
    if (LEVEL_WARN >= level) {
        LOG4CPLUS_WARN(getUseLogger(), log_info);
    }
}

void CLog::warn(const char* log_info, ...)
{
    if (LEVEL_WARN >= level) {
        va_list args; 
        va_start(args, log_info);
        char buf[MAX_BUFFER_LENGTH] = {0}; 
        vsnprintf(buf, sizeof(buf), log_info, args); 
        va_end(args); 
        getUseLogger().forcedLog(log4cplus::WARN_LOG_LEVEL, buf);
    }
}


void CLog::error(const std::string &log_info)
{
    if (LEVEL_ERROR >= level) {
        LOG4CPLUS_ERROR(getUseLogger(), log_info);
    }
}

void CLog::error(const char* log_info, ...)
{
    if (LEVEL_ERROR >= level) {
        va_list args; 
        va_start(args, log_info);
        char buf[MAX_BUFFER_LENGTH] = {0}; 
        vsnprintf(buf, sizeof(buf), log_info, args); 
        va_end(args); 
        getUseLogger().forcedLog(log4cplus::ERROR_LOG_LEVEL, buf);
    }
}

void CLog::putTag(std::map<std::string, std::string>& log_map)
{
    STRING_MAP_IT it = log_map.begin();

    if (log_map.empty()) return;

    std::string info(" ");
    while(it != log_map.end())
    {
        info += it->first;
	info += "=";
        info += it->second;
	info += " ";
        it++;         
    }
    info.erase(info.end()-1);

    RemoteProcessCall rpc(app_key);
    std::string res = XMDT_PREFIX  + rpc.getTraceId() + info + XMDT_SUFFIX;    
    LOG4CPLUS_INFO(info_pLogger, res);
}

void CLog:: putTag(std::map<char*, char*>& log_map)
{
    CHAR_MAP_IT it = log_map.begin();

    if (log_map.empty()) return;

    std::string info(" ");
    while(it != log_map.end())
    {
        info += it->first;
	    info += "=";
        info += it->second;
	    info += " ";
        it++;         
    }
    info.erase(info.end()-1);

    RemoteProcessCall rpc(app_key);
    std::string res = XMDT_PREFIX  + rpc.getTraceId() + info + XMDT_SUFFIX;    
    LOG4CPLUS_INFO(info_pLogger, res);
}

