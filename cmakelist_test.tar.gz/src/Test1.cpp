


 int get(int v)
 {
	return v*v;
 }
